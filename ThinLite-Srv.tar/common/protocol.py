"""ThinLite control-channel protocol.

Media (screen + H.264) travels over RTSP.  Everything that has to travel
*upstream* (mouse, keyboard, keepalive) travels over a single RFC 6455
WebSocket carrying compact UTF-8 JSON text frames.

Why a WebSocket rather than WebRTC for the control path: latency of a
40-byte input event is dominated by the network round trip, not by the
transport, and a WebSocket needs no ICE/STUN/DTLS/SDP machinery at either
end.  It also keeps the client import-free on Raspberry Pi OS.

  client -> server
    hello        {"t":"hello","proto":1,"token":"...","name":"host"}   (first frame)
    pointer      {"t":"pointer","x":0.42,"y":0.71}     normalised absolute position
    button       {"t":"button","b":1,"down":true}      b: 1 L, 2 M, 3 R, 4 side, 5 extra
    wheel        {"t":"wheel","dx":0,"dy":1}           dy > 0 == wheel up
    key          {"t":"key","code":30,"name":"a","down":true}
    release_all  {"t":"release_all"}                   drop every held key/button
    ping         {"t":"ping","ts":1234.5}
    bye          {"t":"bye"}

  server -> client
    welcome      {"t":"welcome","proto":1,"width":1920,"height":1080,
                  "fps":60,"bitrate":5000,"encoder":"libx264","path":"screen",
                  "server":"linux"}
    notify       {"t":"notify","level":"info","msg":"..."}
    error        {"t":"error","code":"auth","msg":"..."}
    pong         {"t":"pong","ts":1234.5}

The pointer is *absolute and normalised* on purpose: the client never has
to know the server's resolution, and the server never has to accumulate
deltas (which drift and fight with pointer acceleration).
"""

from __future__ import annotations

import json

PROTO_VERSION = 1

# client -> server
C_HELLO = "hello"
C_POINTER = "pointer"
C_BUTTON = "button"
C_WHEEL = "wheel"
C_KEY = "key"
C_RELEASE_ALL = "release_all"
C_PING = "ping"
C_BYE = "bye"

# server -> client
S_WELCOME = "welcome"
S_NOTIFY = "notify"
S_ERROR = "error"
S_PONG = "pong"

MAX_MESSAGE_BYTES = 64 * 1024
HELLO_TIMEOUT = 5.0

#: Pointer button ids used on the wire.
BTN_LEFT, BTN_MIDDLE, BTN_RIGHT, BTN_SIDE, BTN_EXTRA = 1, 2, 3, 4, 5


class ProtocolError(Exception):
    """A frame was not valid JSON or did not look like a protocol message."""


def dumps(message):
    """Serialise one control message to a compact JSON string."""
    try:
        return json.dumps(message, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as exc:  # pragma: no cover - programmer error
        raise ProtocolError("message is not JSON serialisable: %s" % exc) from exc


def loads(payload):
    """Parse one control message.

    Accepts ``bytes`` or ``str``.  Raises :class:`ProtocolError` when the
    payload is not a JSON object with a string ``t`` field.
    """
    if isinstance(payload, (bytes, bytearray, memoryview)):
        try:
            payload = bytes(payload).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ProtocolError("payload is not valid UTF-8") from exc
    if not isinstance(payload, str):
        raise ProtocolError("payload must be str or bytes")
    if len(payload) > MAX_MESSAGE_BYTES:
        raise ProtocolError("message too large")
    try:
        message = json.loads(payload)
    except ValueError as exc:
        raise ProtocolError("invalid JSON: %s" % exc) from exc
    if not isinstance(message, dict):
        raise ProtocolError("message must be a JSON object")
    if not isinstance(message.get("t"), str):
        raise ProtocolError("message has no string 't' field")
    return message


def clamp_unit(value):
    """Clamp a normalised coordinate into [0.0, 1.0]."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        return 0.0
    if value != value:  # NaN
        return 0.0
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value


# ---------------------------------------------------------------------------
# Linux evdev key codes <-> stable, platform independent key names
# ---------------------------------------------------------------------------
# The client reads evdev and sends *both* the numeric code and a name.  The
# server only trusts the name, so a future client on another OS can send the
# same names without shipping evdev at all.

KEY_CODES = {
    "esc": 1,
    "1": 2, "2": 3, "3": 4, "4": 5, "5": 6,
    "6": 7, "7": 8, "8": 9, "9": 10, "0": 11,
    "minus": 12, "equal": 13, "backspace": 14, "tab": 15,
    "q": 16, "w": 17, "e": 18, "r": 19, "t": 20, "y": 21, "u": 22,
    "i": 23, "o": 24, "p": 25,
    "bracketleft": 26, "bracketright": 27, "enter": 28, "ctrl_l": 29,
    "a": 30, "s": 31, "d": 32, "f": 33, "g": 34, "h": 35, "j": 36,
    "k": 37, "l": 38,
    "semicolon": 39, "apostrophe": 40, "grave": 41, "shift_l": 42,
    "backslash": 43,
    "z": 44, "x": 45, "c": 46, "v": 47, "b": 48, "n": 49, "m": 50,
    "comma": 51, "period": 52, "slash": 53, "shift_r": 54,
    "kpasterisk": 55, "alt_l": 56, "space": 57, "capslock": 58,
    "f1": 59, "f2": 60, "f3": 61, "f4": 62, "f5": 63,
    "f6": 64, "f7": 65, "f8": 66, "f9": 67, "f10": 68,
    "numlock": 69, "scrolllock": 70,
    "kp7": 71, "kp8": 72, "kp9": 73, "kpminus": 74,
    "kp4": 75, "kp5": 76, "kp6": 77, "kpplus": 78,
    "kp1": 79, "kp2": 80, "kp3": 81, "kp0": 82, "kpdot": 83,
    "102nd": 86, "f11": 87, "f12": 88,
    "kpenter": 96, "ctrl_r": 97, "kpslash": 98, "sysrq": 99,
    "alt_r": 100, "home": 102, "up": 103, "pageup": 104, "left": 105,
    "right": 106, "end": 107, "down": 108, "pagedown": 109,
    "insert": 110, "delete": 111,
    "mute": 113, "volumedown": 114, "volumeup": 115,
    "kpequal": 117, "pause": 119,
    "meta_l": 125, "meta_r": 126, "menu": 139,
    "browser_back": 158, "browser_forward": 159,
    "nextsong": 163, "playpause": 164, "previoussong": 165, "stopcd": 166,
    "browser_refresh": 173, "print": 210,
}

EVDEV_TO_NAME = {code: name for name, code in KEY_CODES.items()}

#: Modifier key names, used for the escape chord and for macOS event flags.
MODIFIER_NAMES = frozenset(
    ("ctrl_l", "ctrl_r", "shift_l", "shift_r", "alt_l", "alt_r", "meta_l", "meta_r")
)


def key_name(code):
    """Map an evdev key code to a protocol key name (``None`` if unknown)."""
    return EVDEV_TO_NAME.get(code)
