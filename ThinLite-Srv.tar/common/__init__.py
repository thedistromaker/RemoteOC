"""Shared code for the ThinLite thin-client pair.

`common` is deliberately dependency free (stdlib only) because the client
side has to run on a Raspberry Pi Zero 2 W running Raspberry Pi OS, where
installing wheels is slow and sometimes impossible.
"""

__version__ = "1.0.0"
