"""A small, dependency-free RFC 6455 WebSocket implementation.

Both the ThinLite server and the ThinLite client use this module instead of
the ``websockets`` package so that the client runs on a stock Raspberry Pi
OS image with no pip step.

Scope (intentionally limited to what ThinLite needs):

* server and client handshake over plain TCP (``ws://``)
* text and binary frames, fragmented messages
* ping/pong and the close handshake
* client-side masking as required by the RFC
* size limits so a hostile peer cannot allocate unbounded memory

Not implemented: TLS, extensions (``permessage-deflate``), subprotocols.
The protocol is only ever run over a trusted LAN/VPN; see README security
notes.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import struct

GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

OP_CONT = 0x0
OP_TEXT = 0x1
OP_BINARY = 0x2
OP_CLOSE = 0x8
OP_PING = 0x9
OP_PONG = 0xA

CONTROL_OPCODES = (OP_CLOSE, OP_PING, OP_PONG)

#: Largest single message accepted from the peer.
MAX_PAYLOAD = 256 * 1024
#: Largest HTTP handshake head accepted from the peer.
MAX_HEADER_BYTES = 16 * 1024
#: Read buffer size; must comfortably exceed MAX_PAYLOAD.
STREAM_LIMIT = MAX_PAYLOAD + 64 * 1024

CLOSE_NORMAL = 1000
CLOSE_GOING_AWAY = 1001
CLOSE_PROTOCOL_ERROR = 1002
CLOSE_UNSUPPORTED = 1003
CLOSE_TOO_BIG = 1009
CLOSE_TRY_AGAIN = 1013


class WebSocketError(Exception):
    """Handshake or framing failure."""


class WebSocketClosed(WebSocketError):
    """The peer (or the transport) closed the connection."""

    def __init__(self, code=1006, reason=""):
        text = "websocket closed (%d)" % code
        if reason:
            text += ": %s" % reason
        super().__init__(text)
        self.code = code
        self.reason = reason


def _apply_mask(payload, key):
    """XOR ``payload`` with the repeating 4-byte ``key``."""
    length = len(payload)
    if not length:
        return b""
    keystream = (key * (length // 4 + 1))[:length]
    return (int.from_bytes(payload, "big") ^ int.from_bytes(keystream, "big")).to_bytes(
        length, "big"
    )


def accept_key(client_key):
    """Compute ``Sec-WebSocket-Accept`` for a ``Sec-WebSocket-Key``."""
    digest = hashlib.sha1(client_key.encode("ascii") + GUID).digest()
    return base64.b64encode(digest).decode("ascii")


async def _read_http_head(reader, max_bytes=MAX_HEADER_BYTES):
    chunks = []
    total = 0
    while True:
        try:
            line = await reader.readuntil(b"\r\n")
        except asyncio.IncompleteReadError as exc:
            raise WebSocketError("connection closed during handshake") from exc
        except asyncio.LimitOverrunError as exc:
            raise WebSocketError("handshake line too long") from exc
        total += len(line)
        if total > max_bytes:
            raise WebSocketError("handshake too large")
        chunks.append(line)
        if line == b"\r\n":
            return b"".join(chunks)


def _parse_head(head):
    try:
        text = head.decode("latin-1")
    except UnicodeDecodeError as exc:  # pragma: no cover - latin-1 never fails
        raise WebSocketError("invalid handshake encoding") from exc
    lines = text.split("\r\n")
    start_line = lines[0]
    headers = {}
    for line in lines[1:]:
        if not line:
            continue
        if ":" not in line:
            raise WebSocketError("malformed header line")
        name, _, value = line.partition(":")
        name = name.strip().lower()
        value = value.strip()
        if name in headers:
            headers[name] = headers[name] + ", " + value
        else:
            headers[name] = value
    return start_line, headers


class WebSocket:
    """One established WebSocket connection."""

    def __init__(self, reader, writer, *, mask_outgoing, max_payload=MAX_PAYLOAD):
        self._reader = reader
        self._writer = writer
        self._mask_outgoing = mask_outgoing
        self._max_payload = max_payload
        self._closed = False

    # -- properties ---------------------------------------------------------
    @property
    def closed(self):
        return self._closed

    @property
    def peer(self):
        info = self._writer.get_extra_info("peername")
        if not info:
            return "?"
        return "%s:%s" % (info[0], info[1])

    # -- sending ------------------------------------------------------------
    async def ping(self, payload=b""):
        await self._send_frame(payload[:125], OP_PING)

    async def send_text(self, text):
        await self._send_frame(text.encode("utf-8"), OP_TEXT)

    async def send_binary(self, data):
        await self._send_frame(bytes(data), OP_BINARY)

    async def send(self, data):
        """Send ``str`` as a text frame or ``bytes`` as a binary frame."""
        if isinstance(data, str):
            await self.send_text(data)
        else:
            await self.send_binary(data)

    async def _send_frame(self, payload, opcode):
        if self._closed:
            raise WebSocketClosed(CLOSE_GOING_AWAY, "already closed")
        length = len(payload)
        header = bytearray()
        header.append(0x80 | opcode)
        mask_bit = 0x80 if self._mask_outgoing else 0x00
        if length < 126:
            header.append(mask_bit | length)
        elif length < 65536:
            header.append(mask_bit | 126)
            header += struct.pack("!H", length)
        else:
            header.append(mask_bit | 127)
            header += struct.pack("!Q", length)
        if self._mask_outgoing:
            key = os.urandom(4)
            header += key
            payload = _apply_mask(payload, key)
        frame = bytes(header) + payload
        try:
            self._writer.write(frame)
            await self._writer.drain()
        except (ConnectionError, RuntimeError) as exc:
            self._closed = True
            raise WebSocketClosed(1006, "write failed") from exc

    # -- receiving ----------------------------------------------------------
    async def recv(self):
        """Return ``(opcode, payload)`` for the next data message.

        Control frames are handled internally.  Raises :class:`WebSocketClosed`
        when the peer closes the connection.
        """
        fragments = []
        message_opcode = None
        total = 0
        while True:
            fin, opcode, payload = await self._read_frame()
            if opcode == OP_PING:
                await self._send_frame(payload[:125], OP_PONG)
                continue
            if opcode == OP_PONG:
                continue
            if opcode == OP_CLOSE:
                code, reason = 1005, ""
                if len(payload) >= 2:
                    code = struct.unpack("!H", payload[:2])[0]
                    reason = payload[2:].decode("utf-8", "replace")
                await self._close_quietly(payload[:125])
                raise WebSocketClosed(code, reason)
            if opcode == OP_CONT:
                if message_opcode is None:
                    raise WebSocketError("continuation frame without a start frame")
            elif opcode in (OP_TEXT, OP_BINARY):
                if message_opcode is not None:
                    raise WebSocketError("new data frame inside a fragmented message")
                message_opcode = opcode
            else:
                raise WebSocketError("unsupported opcode 0x%x" % opcode)

            fragments.append(payload)
            total += len(payload)
            if total > self._max_payload:
                raise WebSocketError("message exceeds %d bytes" % self._max_payload)
            if fin:
                return message_opcode, b"".join(fragments)

    async def _read_frame(self):
        header = await self._exactly(2)
        byte0, byte1 = header[0], header[1]
        if byte0 & 0x70:
            raise WebSocketError("reserved bits set (no extensions negotiated)")
        fin = bool(byte0 & 0x80)
        opcode = byte0 & 0x0F
        masked = bool(byte1 & 0x80)
        length = byte1 & 0x7F
        if length == 126:
            length = struct.unpack("!H", await self._exactly(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", await self._exactly(8))[0]
        if opcode in CONTROL_OPCODES:
            if not fin:
                raise WebSocketError("fragmented control frame")
            if length > 125:
                raise WebSocketError("control frame payload too large")
        if length > self._max_payload:
            raise WebSocketError("frame exceeds %d bytes" % self._max_payload)
        # A client must mask, a server must not.  Reject anything else so a
        # stray HTTP client cannot inject input into the thin client.
        if masked == self._mask_outgoing:
            raise WebSocketError("incorrect frame masking for this peer")
        key = await self._exactly(4) if masked else b""
        payload = await self._exactly(length) if length else b""
        if masked:
            payload = _apply_mask(payload, key)
        return fin, opcode, payload

    async def _exactly(self, count):
        try:
            return await self._reader.readexactly(count)
        except (asyncio.IncompleteReadError, ConnectionError) as exc:
            self._closed = True
            raise WebSocketClosed(1006, "connection lost") from exc

    # -- closing ------------------------------------------------------------
    async def _close_quietly(self, payload):
        if self._closed:
            return
        self._closed = True
        try:
            frame = bytes([0x80 | OP_CLOSE])
            if self._mask_outgoing:
                key = os.urandom(4)
                frame += bytes([0x80 | len(payload)]) + key + _apply_mask(payload, key)
            else:
                frame += bytes([len(payload)]) + payload
            self._writer.write(frame)
            await self._writer.drain()
        except Exception:
            pass

    async def close(self, code=CLOSE_NORMAL, reason=""):
        if not self._closed:
            payload = struct.pack("!H", code) + reason.encode("utf-8")[:123]
            await self._close_quietly(payload)
        await self._shutdown()

    async def _shutdown(self):
        self._closed = True
        try:
            self._writer.close()
            await self._writer.wait_closed()
        except Exception:
            pass


async def accept(reader, writer, *, timeout=10.0, max_payload=MAX_PAYLOAD):
    """Perform the server side of the handshake.

    Returns ``(websocket, request_path, headers)``.  Raises
    :class:`WebSocketError` (and leaves the socket to the caller) on failure.
    """
    try:
        head = await asyncio.wait_for(_read_http_head(reader), timeout)
    except asyncio.TimeoutError as exc:
        raise WebSocketError("handshake timeout") from exc
    start_line, headers = _parse_head(head)
    parts = start_line.split(" ")
    if len(parts) != 3:
        raise WebSocketError("malformed request line")
    method, target, _version = parts
    if method.upper() != "GET":
        raise WebSocketError("handshake must use GET")
    if headers.get("upgrade", "").lower() != "websocket":
        raise WebSocketError("missing 'Upgrade: websocket'")
    if "upgrade" not in headers.get("connection", "").lower():
        raise WebSocketError("missing 'Connection: Upgrade'")
    if headers.get("sec-websocket-version") != "13":
        raise WebSocketError("unsupported Sec-WebSocket-Version")
    client_key = headers.get("sec-websocket-key")
    if not client_key:
        raise WebSocketError("missing Sec-WebSocket-Key")
    response = (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        "Sec-WebSocket-Accept: %s\r\n\r\n" % accept_key(client_key)
    )
    try:
        writer.write(response.encode("ascii"))
        await writer.drain()
    except (ConnectionError, RuntimeError) as exc:
        raise WebSocketError("failed to send handshake response") from exc
    return WebSocket(reader, writer, mask_outgoing=False, max_payload=max_payload), target, headers


async def connect(host, port, path="/", *, timeout=10.0, max_payload=MAX_PAYLOAD):
    """Open a client WebSocket to ``host:port``."""
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port, limit=STREAM_LIMIT), timeout
        )
    except asyncio.TimeoutError as exc:
        raise WebSocketError("connection to %s:%s timed out" % (host, port)) from exc
    except OSError as exc:
        raise WebSocketError("cannot connect to %s:%s (%s)" % (host, port, exc)) from exc

    key = base64.b64encode(os.urandom(16)).decode("ascii")
    request = (
        "GET %s HTTP/1.1\r\n"
        "Host: %s:%s\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        "Sec-WebSocket-Key: %s\r\n"
        "Sec-WebSocket-Version: 13\r\n\r\n" % (path, host, port, key)
    )
    try:
        writer.write(request.encode("ascii"))
        await writer.drain()
        head = await asyncio.wait_for(_read_http_head(reader), timeout)
    except asyncio.TimeoutError as exc:
        writer.close()
        raise WebSocketError("handshake with %s:%s timed out" % (host, port)) from exc
    except (OSError, WebSocketError) as exc:
        writer.close()
        raise WebSocketError("handshake failed: %s" % exc) from exc

    start_line, headers = _parse_head(head)
    parts = start_line.split(" ")
    if len(parts) < 2 or parts[1] != "101":
        writer.close()
        raise WebSocketError("server refused the upgrade: %s" % start_line)
    if headers.get("sec-websocket-accept") != accept_key(key):
        writer.close()
        raise WebSocketError("invalid Sec-WebSocket-Accept from server")
    return WebSocket(reader, writer, mask_outgoing=True, max_payload=max_payload)
