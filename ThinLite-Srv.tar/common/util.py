"""Small helpers shared by both halves: config paths, logging, tokens."""

from __future__ import annotations

import logging
import os
import secrets
import socket
import sys
from pathlib import Path

APP_NAME = "thincast"
LOG_FORMAT = "%(asctime)s %(levelname)-7s %(name)-14s %(message)s"


def config_dir(app=APP_NAME):
    """Return (and create) the per-user configuration directory."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    elif sys.platform == "darwin":
        base = str(Path.home() / "Library" / "Application Support")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    path = Path(base) / app
    path.mkdir(parents=True, exist_ok=True)
    return path


def state_dir(app=APP_NAME):
    """Return (and create) a per-user directory for logs and binaries."""
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = str(Path.home() / "Library" / "Application Support")
    else:
        base = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    path = Path(base) / app
    path.mkdir(parents=True, exist_ok=True)
    return path


def setup_logging(verbose=False, name=None):
    """Configure root logging once and return a logger."""
    level = logging.DEBUG if verbose else logging.INFO
    root = logging.getLogger()
    if not root.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter(LOG_FORMAT))
        root.addHandler(handler)
    root.setLevel(level)
    return logging.getLogger(name) if name else root


def new_token(nbytes=24):
    """Create a URL-safe shared secret (chars: A-Za-z0-9_-)."""
    return secrets.token_urlsafe(nbytes)


def local_ip():
    """Best-effort primary LAN address of this machine."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # No packet is sent; connect() just selects a route.
        probe.connect(("10.255.255.255", 1))
        return probe.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        probe.close()


def fmt_bitrate(kbps):
    if kbps >= 1000:
        return "%.1f Mbps" % (kbps / 1000.0)
    return "%d kbps" % kbps
