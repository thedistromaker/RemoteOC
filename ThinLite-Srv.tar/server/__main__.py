"""CLI entry point for the ThinLite host.

    python3 -m server                 # normal start
    python3 -m server --check         # dependency / backend report
    python3 -m server --download-mediamtx
"""

from __future__ import annotations

import argparse
import asyncio
import os
import signal
import sys
import time
from pathlib import Path
from urllib.parse import quote

from common.util import fmt_bitrate, local_ip, setup_logging, state_dir
from server import capture
from server import config as server_config
from server import mediamtx
from server.control import ControlServer
from server.inject import InjectorError, create_injector


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(
        prog="python3 -m server",
        description="ThinLite host: share this machine's screen over RTSP and accept "
                    "remote mouse/keyboard over a WebSocket control channel.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--config", help="config file (default: <config dir>/server.json)")
    parser.add_argument("--host", help="bind address for the control channel")
    parser.add_argument("--control-port", type=int, help="control WebSocket port")
    parser.add_argument("--rtsp-port", type=int, help="MediaMTX RTSP port")
    parser.add_argument("--path", help="RTSP path name, e.g. 'screen'")
    parser.add_argument("--width", type=int, help="encoded width (must be even)")
    parser.add_argument("--height", type=int, help="encoded height (must be even)")
    parser.add_argument("--fps", type=int, help="capture frame rate")
    parser.add_argument("--bitrate", type=int, metavar="KBPS", help="target bitrate in kbit/s")
    parser.add_argument("--encoder", help="auto, libx264, videotoolbox, nvenc, qsv, v4l2m2m")
    parser.add_argument("--capture", help="auto, x11grab, gdigrab, ddagrab, avfoundation, pipewire")
    parser.add_argument("--capture-region", help="WxH+X+Y capture rectangle")
    parser.add_argument("--display", help="X11 display for x11grab (default: $DISPLAY)")
    parser.add_argument("--input-args", help="extra ffmpeg input arguments (shell-quoted string)")
    parser.add_argument("--inject", help="auto, xtest, uinput, win32, macos, none")
    parser.add_argument("--token", help="override the client access token")
    parser.add_argument("--rtsp-user", help="override the RTSP username")
    parser.add_argument("--rtsp-pass", help="override the RTSP password")
    parser.add_argument("--mediamtx-bin", help="path to an existing mediamtx binary")
    parser.add_argument("--mediamtx-version", help="MediaMTX release tag to download")
    parser.add_argument("--download-mediamtx", action="store_true",
                        help="download a pinned MediaMTX release into the state directory")
    parser.add_argument("--no-mediamtx", action="store_true",
                        help="do not run MediaMTX; publish to --publish-url instead")
    parser.add_argument("--publish-url", help="external RTSP publish URL (implies --no-mediamtx)")
    parser.add_argument("--no-capture", action="store_true",
                        help="control channel only (no ffmpeg); useful for testing")
    parser.add_argument("--no-takeover", action="store_true",
                        help="refuse a second client instead of replacing the current one")
    parser.add_argument("--check", action="store_true", help="report backends and exit")
    parser.add_argument("--verbose", "-v", action="store_true", help="debug logging")
    return parser


def apply_cli(cfg, args):
    override = {
        "host": args.host,
        "control_port": args.control_port,
        "rtsp_port": args.rtsp_port,
        "path": args.path,
        "width": args.width,
        "height": args.height,
        "fps": args.fps,
        "bitrate_kbps": args.bitrate,
        "encoder": args.encoder,
        "capture": args.capture,
        "capture_region": args.capture_region,
        "display": args.display,
        "inject": args.inject,
        "token": args.token,
        "rtsp_user": args.rtsp_user,
        "rtsp_pass": args.rtsp_pass,
        "mediamtx_bin": args.mediamtx_bin,
        "mediamtx_version": args.mediamtx_version,
        "publish_url": args.publish_url,
    }
    for key, value in override.items():
        if value is not None:
            setattr(cfg, key, value)
    if args.input_args:
        cfg.input_args = args.input_args.split()
    if args.no_mediamtx or args.publish_url:
        cfg.manage_mediamtx = False
    if args.no_takeover:
        cfg.allow_takeover = False


# ---------------------------------------------------------------------------
# ffmpeg supervisor
# ---------------------------------------------------------------------------
class EncoderSupervisor:
    """Keeps ffmpeg publishing, restarts it, and falls back to libx264."""

    def __init__(self, cfg, publish_url, log, log_path):
        self.cfg = cfg
        self.publish_url = publish_url
        self.log = log
        self.log_path = str(log_path)
        self.encoder = capture.resolve_encoder(cfg.encoder, cfg.ffmpeg)
        self.process = None
        self.failures = 0

    async def run(self, stop):
        while not stop.is_set():
            try:
                cmd, _capture_name, encoder = capture.build_command(
                    self.cfg, self.publish_url, self.encoder)
            except capture.CaptureError as exc:
                self.log.error("cannot build capture pipeline: %s", exc)
                return
            self.encoder = encoder
            self.log.info("capture: %s", " ".join(cmd))
            started = time.monotonic()
            handle = open(self.log_path, "ab", buffering=0)
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=handle,
                )
            except (OSError, ValueError) as exc:
                handle.close()
                self.log.error("cannot start ffmpeg: %s", exc)
                await _sleep_unless(stop, 5.0)
                continue
            self.process = proc
            waiter = asyncio.create_task(proc.wait())
            stopper = asyncio.create_task(stop.wait())
            await asyncio.wait({waiter, stopper}, return_when=asyncio.FIRST_COMPLETED)
            if not waiter.done():
                # Shutting down: ask ffmpeg to exit, then insist.
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass
                try:
                    await asyncio.wait_for(waiter, 5.0)
                except asyncio.TimeoutError:
                    proc.kill()
                    await asyncio.wait_for(waiter, 5.0)
            stopper.cancel()
            handle.close()
            self.process = None
            if stop.is_set():
                return

            survived = time.monotonic() - started
            reason = mediamtx.tail_log(self.log_path, 8)
            self.log.warning(
                "ffmpeg exited with code %s after %.1fs%s",
                proc.returncode, survived, ("\n" + reason) if reason else "",
            )
            if survived > 10.0:
                self.failures = 1
            else:
                self.failures += 1
            if self.failures >= 2 and self.encoder != "libx264":
                self.log.warning("encoder %s keeps failing; falling back to libx264", self.encoder)
                self.encoder = "libx264"
                self.failures = 1
            delay = min(8.0, 1.0 * (2 ** max(0, self.failures - 1)))
            await _sleep_unless(stop, delay)

    async def terminate(self):
        proc = self.process
        if proc is None or proc.returncode is not None:
            return
        try:
            proc.terminate()
        except ProcessLookupError:
            return
        try:
            await asyncio.wait_for(proc.wait(), 5.0)
        except asyncio.TimeoutError:
            proc.kill()


async def _sleep_unless(stop, seconds):
    try:
        await asyncio.wait_for(stop.wait(), seconds)
    except asyncio.TimeoutError:
        pass


# ---------------------------------------------------------------------------
# Runtime
# ---------------------------------------------------------------------------
def publish_url_for(cfg):
    if cfg.publish_url:
        return cfg.publish_url
    return "rtsp://%s:%s@127.0.0.1:%d/%s" % (
        quote(cfg.rtsp_user, safe=""),
        quote(cfg.rtsp_pass, safe=""),
        cfg.rtsp_port,
        cfg.path,
    )


def banner(cfg, injector_name, encoder_desc, control_port):
    ip = local_ip()
    lines = [
        "",
        "=" * 68,
        " ThinLite host ready",
        "   control : ws://%s:%d/control" % (ip, control_port),
        "   video   : rtsp://%s:%d/%s" % (ip, cfg.rtsp_port, cfg.path),
        "   rtsp user/pass : %s / %s" % (cfg.rtsp_user, cfg.rtsp_pass),
        "   token   : %s" % cfg.token,
        "   encode  : %s, %s" % (encoder_desc, fmt_bitrate(cfg.bitrate_kbps)),
        "   input   : %s" % injector_name,
        "",
        " Add these values in the ThinLite client (\"Add server\"),",
        " or on the Pi:  python3 -m client --connect NAME",
        " Press Ctrl+C to stop.",
        "=" * 68,
        "",
    ]
    return "\n".join(lines)


async def run(cfg, args, log):
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    _install_signals(loop, stop, log)

    injector = create_injector(cfg.inject, log.info)

    mtx_process = None
    encoder = None
    control = None
    try:
        if cfg.manage_mediamtx:
            binary = mediamtx.find_binary(cfg.mediamtx_bin)
            if not binary:
                if args.download_mediamtx:
                    version = cfg.mediamtx_version or mediamtx.DEFAULT_VERSION
                    binary = mediamtx.download(version, log=log.info)
                    cfg.mediamtx_bin = binary
                    server_config.save(cfg, args.config)
                else:
                    raise SystemExit(
                        "MediaMTX not found. Install it, pass --mediamtx-bin, "
                        "or run with --download-mediamtx."
                    )
            mtx_config = mediamtx.write_config(
                mediamtx.config_path(),
                rtsp_port=cfg.rtsp_port,
                rtsp_user=cfg.rtsp_user,
                rtsp_pass=cfg.rtsp_pass,
                stream_path=cfg.path,
                log_level="debug" if args.verbose else "info",
            )
            log_file = state_dir() / "mediamtx.log"
            mtx_process = mediamtx.start(binary, mtx_config, log_file, log.info)
            await mediamtx.wait_ready(cfg.rtsp_port, process=mtx_process, timeout=15.0)
            log.info("MediaMTX is serving RTSP on port %d", cfg.rtsp_port)

        publish_url = publish_url_for(cfg)

        if args.no_capture:
            encoder_desc = "capture disabled"
        else:
            encoder = EncoderSupervisor(cfg, publish_url, log, state_dir() / "ffmpeg.log")
            asyncio.create_task(encoder.run(stop), name="ffmpeg-supervisor")
            encoder_desc = capture.describe(cfg)

        control = ControlServer(
            token=cfg.token,
            injector=injector,
            info={
                "fps": int(cfg.fps),
                "bitrate": int(cfg.bitrate_kbps),
                "encoder": (encoder.encoder if encoder else "none"),
                "path": cfg.path,
            },
            host=cfg.host,
            port=cfg.control_port,
            allow_takeover=cfg.allow_takeover,
            logger=log,
        )
        await control.start()
        print(banner(cfg, injector.name, encoder_desc, control.port), flush=True)

        await stop.wait()
        log.info("shutting down")
    finally:
        if control is not None:
            await control.stop()
        if encoder is not None:
            await encoder.terminate()
        if mtx_process is not None and mtx_process.poll() is None:
            mtx_process.terminate()
            try:
                await asyncio.get_running_loop().run_in_executor(None, mtx_process.wait, 5)
            except Exception:
                mtx_process.kill()
        injector.close()


def _install_signals(loop, stop, log):
    def trigger():
        stop.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, trigger)
        except (NotImplementedError, RuntimeError, AttributeError):
            # Windows: fall back to the synchronous handler.
            try:
                signal.signal(sig, lambda *_: loop.call_soon_threadsafe(trigger))
            except (ValueError, OSError):
                pass
    if sys.platform == "win32":
        try:
            signal.signal(signal.SIGBREAK, lambda *_: loop.call_soon_threadsafe(trigger))
        except (AttributeError, ValueError, OSError):
            pass


def do_check(cfg):
    print("ThinLite host check")
    print("  platform      : %s %s" % (sys.platform, os.uname().machine if hasattr(os, "uname") else ""))
    print("  config file   : %s" % server_config.config_path())
    print("  config dir    : %s" % state_dir())
    ffmpeg = cfg.ffmpeg
    try:
        version = capture.subprocess.run(
            [ffmpeg, "-version"], stdout=capture.subprocess.PIPE,
            stderr=capture.subprocess.STDOUT, timeout=15, check=False,
        ).stdout.decode("utf-8", "replace").splitlines()[0]
        print("  ffmpeg        : %s" % version)
        encoders = capture.probe_encoders(ffmpeg)
        print("  h264 encoders : %s" % (", ".join(sorted(encoders)) or "none found"))
        print("  will use      : %s" % capture.resolve_encoder(cfg.encoder, ffmpeg))
        print("  capture       : %s" % capture.detect_capture(cfg.capture))
    except (OSError, IndexError, capture.CaptureError) as exc:
        print("  ffmpeg        : NOT USABLE (%s)" % exc)
    binary = mediamtx.find_binary(cfg.mediamtx_bin)
    print("  mediamtx      : %s" % (binary or "not found (use --download-mediamtx)"))
    try:
        injector = create_injector(cfg.inject if not cfg.inject == "auto" else
                                   ("none" if cfg.inject == "none" else "auto"))
        print("  input backend : %s %s" % (injector.name, injector.screen_size()))
        injector.close()
    except InjectorError as exc:
        print("  input backend : UNAVAILABLE (%s)" % exc)
    return 0


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    log = setup_logging(args.verbose, "server")

    cfg = server_config.load(args.config)
    apply_cli(cfg, args)
    try:
        cfg.validate()
    except ValueError as exc:
        parser.error(str(exc))

    if args.check:
        return do_check(cfg)

    path = server_config.save(cfg, args.config)
    log.info("configuration: %s", path)
    if not args.no_capture and not cfg.manage_mediamtx and not cfg.publish_url:
        parser.error("--no-mediamtx needs --publish-url")
    try:
        return asyncio.run(run(cfg, args, log)) or 0
    except KeyboardInterrupt:
        return 0
    except InjectorError as exc:
        print("input injection unavailable: %s" % exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
