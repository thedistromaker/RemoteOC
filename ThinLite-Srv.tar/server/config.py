"""Persistent server configuration.

Every secret is generated once and then reused, so a client only has to be
configured a single time.  The file lives in the per-user config directory
and is chmod 600 on POSIX systems.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

from common.util import config_dir, new_token

CONFIG_NAME = "server.json"


@dataclass
class ServerConfig:
    # network
    host: str = "0.0.0.0"
    control_port: int = 8765
    rtsp_port: int = 8554
    path: str = "screen"

    # capture / encode
    width: int = 1280
    height: int = 720
    fps: int = 60
    bitrate_kbps: int = 5000
    encoder: str = "auto"
    capture: str = "auto"
    capture_region: str = ""
    display: str = ""
    input_args: list = field(default_factory=list)
    ffmpeg: str = "ffmpeg"

    # input injection
    inject: str = "auto"
    allow_takeover: bool = True

    # credentials
    token: str = ""
    rtsp_user: str = "thincast"
    rtsp_pass: str = ""

    # mediamtx
    manage_mediamtx: bool = True
    mediamtx_bin: str = ""
    mediamtx_version: str = ""
    publish_url: str = ""

    def ensure_secrets(self):
        if not self.token:
            self.token = new_token(24)
            self._dirty = True
        if not self.rtsp_pass:
            self.rtsp_pass = new_token(18)
            self._dirty = True

    def validate(self):
        if not (0 < self.control_port < 65536):
            raise ValueError("control port out of range: %d" % self.control_port)
        if not (0 < self.rtsp_port < 65536):
            raise ValueError("RTSP port out of range: %d" % self.rtsp_port)
        if self.width < 160 or self.height < 120:
            raise ValueError("capture size too small")
        if self.width % 2 or self.height % 2:
            raise ValueError("capture width/height must be even (H.264 4:2:0)")
        if not (1 <= self.fps <= 120):
            raise ValueError("fps out of range")
        if not (200 <= self.bitrate_kbps <= 100000):
            raise ValueError("bitrate out of range (kbps)")
        if not self.path or "/" in self.path:
            raise ValueError("path must be a single RTSP path component")


def config_path(explicit=None):
    if explicit:
        return Path(explicit).expanduser()
    return config_dir() / CONFIG_NAME


def load(explicit=None):
    path = config_path(explicit)
    cfg = ServerConfig()
    if path.exists():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise SystemExit("cannot read %s: %s" % (path, exc))
        known = {f for f in asdict(cfg)}
        for key, value in raw.items():
            if key in known:
                setattr(cfg, key, value)
    cfg.ensure_secrets()
    return cfg


def save(cfg, explicit=None):
    path = config_path(explicit)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = asdict(cfg)
    data.pop("_dirty", None)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    if sys.platform != "win32":
        os.chmod(tmp, 0o600)
    os.replace(tmp, path)
    return path
