"""MediaMTX lifecycle: locate, optionally download, configure and supervise.

MediaMTX is the RTSP server that sits between ffmpeg (publisher) and the
thin client (reader).  It is configured to expose *only* RTSP: RTMP, HLS,
WebRTC, SRT, the API, metrics and pprof are all disabled so the host
machine exposes a single port instead of half a dozen.
"""

from __future__ import annotations

import asyncio
import os
import platform
import shutil
import ssl
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

from common.util import config_dir, state_dir

#: Minimum MediaMTX version this configuration file targets (authInternalUsers).
MIN_VERSION = (1, 9, 0)
DEFAULT_VERSION = "v1.21.3"
RELEASE_URL = "https://github.com/bluenviron/mediamtx/releases/download/{ver}/mediamtx_{ver}_{arch}.{ext}"


class MediamtxError(Exception):
    pass


def platform_arch():
    """Return the MediaMTX release asset suffix for this machine."""
    machine = platform.machine().lower()
    if sys.platform == "win32":
        table = {"amd64": "windows_amd64", "x86_64": "windows_amd64", "arm64": "windows_arm64"}
    elif sys.platform == "darwin":
        table = {"arm64": "darwin_arm64", "aarch64": "darwin_arm64", "x86_64": "darwin_amd64"}
    else:
        table = {
            "x86_64": "linux_amd64",
            "amd64": "linux_amd64",
            "aarch64": "linux_arm64v8",
            "arm64": "linux_arm64v8",
            "armv7l": "linux_armv7",
            "armv6l": "linux_armv6",
        }
    arch = table.get(machine)
    if not arch:
        raise MediamtxError("no MediaMTX build for %s/%s" % (sys.platform, machine))
    ext = "zip" if arch.startswith("windows") else "tar.gz"
    return arch, ext


def find_binary(explicit="", download_dir=None):
    """Locate a mediamtx executable, or return ``None``."""
    if explicit:
        path = Path(explicit).expanduser()
        if not path.exists():
            raise MediamtxError("--mediamtx-bin %s does not exist" % path)
        return str(path)
    env = os.environ.get("THINCAST_MEDIAMTX")
    if env and Path(env).exists():
        return env
    found = shutil.which("mediamtx")
    if found:
        return found
    local = (download_dir or (state_dir() / "bin")) / ("mediamtx.exe" if sys.platform == "win32" else "mediamtx")
    if local.exists() and os.access(local, os.X_OK):
        return str(local)
    return None


#: Environment variables that may point at a CA bundle (the first existing one
#: wins).  SSL_CERT_FILE / REQUESTS_CA_BUNDLE / CURL_CA_BUNDLE are already
#: conventional, so corporate setups tend to have one of them set already.
CA_ENV_VARS = ("THINCAST_CA_BUNDLE", "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE")


def _explicit_ca_bundle(ca_bundle=None):
    if ca_bundle:
        path = Path(ca_bundle).expanduser()
        if not path.exists():
            raise MediamtxError("--ca-bundle %s does not exist" % path)
        return str(path)
    for name in CA_ENV_VARS:
        value = os.environ.get(name)
        if not value:
            continue
        path = Path(value).expanduser()
        if path.exists():
            return str(path)
    return None


def _candidate_contexts(ca_bundle=None, insecure=False):
    """``(label, ssl_context)`` pairs to try, most trustworthy first.

    The default context is right for most machines: on Windows it reads the
    system certificate store, which is exactly where a corporate
    TLS-inspection proxy installs its root.  ``certifi`` rescues Python
    builds with no usable system roots.  Disabling verification is opt-in
    and always tried last.
    """
    contexts = []
    explicit = _explicit_ca_bundle(ca_bundle)
    if explicit:
        try:
            contexts.append(("CA bundle %s" % explicit,
                             ssl.create_default_context(cafile=explicit)))
        except (OSError, ssl.SSLError) as exc:
            raise MediamtxError("cannot load CA bundle %s: %s" % (explicit, exc)) from exc
    try:
        contexts.append(("system trust store", ssl.create_default_context()))
    except Exception:  # pragma: no cover - exotic Python builds
        pass
    try:
        import certifi  # optional, never required

        contexts.append(("certifi bundle", ssl.create_default_context(cafile=certifi.where())))
    except Exception:
        pass
    if insecure:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        contexts.append(("NO VERIFICATION", context))
    return contexts


def _fetch(url, archive, context):
    with urllib.request.urlopen(url, timeout=120, context=context) as response:
        status = getattr(response, "status", 200)
        if status != 200:
            raise MediamtxError("download failed: HTTP %s" % status)
        with open(archive, "wb") as handle:
            shutil.copyfileobj(response, handle)


def _ssl_help(url, errors, exe_name):
    detail = "\n  ".join(errors[-3:]) if errors else "no detail available"
    suffix = ".exe" if exe_name.endswith(".exe") else ""
    return (
        "cannot download MediaMTX: TLS certificate verification failed.\n"
        "  attempted:\n  %s\n\n"
        "This is usually a corporate TLS-inspection proxy (Zscaler, Netskope,\n"
        "Kaspersky, ...) or a Python build without CA roots. Pick one:\n\n"
        "  1. Trust your organisation's root CA:\n"
        "       python -m server --download-mediamtx --ca-bundle path\\to\\corp-ca.pem\n"
        "     (or set THINCAST_CA_BUNDLE / SSL_CERT_FILE to that file)\n"
        "  2. Skip the download entirely - fetch this URL in a browser,\n"
        "     unpack it, and point ThinLite at the binary:\n"
        "       %s\n"
        "       python -m server --mediamtx-bin path\\to\\mediamtx%s\n"
        "  3. Only if you accept the risk of an unverified download:\n"
        "       python -m server --download-mediamtx --insecure-download\n"
        % (detail, url, suffix)
    )


def download(version=DEFAULT_VERSION, dest_dir=None, log=None, ca_bundle=None, insecure=False):
    """Download and unpack a MediaMTX release; returns the executable path.

    Retries the transfer with each available trust source, so a missing or
    corporate-only root CA degrades to a clear, actionable error instead of a
    bare ``[SSL: CERTIFICATE_VERIFY_FAILED]``.
    """
    log = log or (lambda msg: None)
    arch, ext = platform_arch()
    dest_dir = Path(dest_dir or (state_dir() / "bin"))
    dest_dir.mkdir(parents=True, exist_ok=True)
    exe_name = "mediamtx.exe" if sys.platform == "win32" else "mediamtx"
    final = dest_dir / exe_name
    url = RELEASE_URL.format(ver=version, arch=arch, ext=ext)

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        archive = tmp_path / ("mediamtx." + ext)
        ssl_errors = []
        fetched = False
        for label, context in _candidate_contexts(ca_bundle, insecure):
            if label.startswith("NO VERIFICATION"):
                log("WARNING: TLS certificate verification disabled for this download")
            log("downloading %s (trust: %s)" % (url, label))
            try:
                _fetch(url, archive, context)
                fetched = True
                break
            except (ssl.SSLError, urllib.error.URLError) as exc:
                reason = getattr(exc, "reason", exc)
                if not isinstance(reason, ssl.SSLError):
                    raise MediamtxError("cannot download MediaMTX: %s" % reason) from exc
                ssl_errors.append("%s: %s" % (label, reason))
                try:
                    archive.unlink()
                except OSError:
                    pass
                continue
            except MediamtxError:
                raise
            except OSError as exc:
                # ssl.SSLError and URLError subclass OSError, so anything that
                # lands here is a real I/O problem (disk full, permission...).
                raise MediamtxError("cannot download MediaMTX: %s" % exc) from exc
        if not fetched:
            raise MediamtxError(_ssl_help(url, ssl_errors, exe_name))

        extracted = None
        if ext == "zip":
            with zipfile.ZipFile(archive) as zf:
                for name in zf.namelist():
                    if os.path.basename(name) == exe_name:
                        zf.extract(name, tmp_path)
                        extracted = tmp_path / name
                        break
        else:
            with tarfile.open(archive, "r:gz") as tf:
                for member in tf.getmembers():
                    if os.path.basename(member.name) == "mediamtx" and member.isfile():
                        tf.extract(member, tmp_path)
                        extracted = tmp_path / member.name
                        break
        if not extracted or not extracted.exists():
            raise MediamtxError("archive did not contain %s" % exe_name)
        shutil.move(str(extracted), str(final))
    if sys.platform != "win32":
        os.chmod(final, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
    log("installed MediaMTX %s at %s" % (version, final))
    return str(final)


def write_config(path, *, rtsp_port, rtsp_user, rtsp_pass, stream_path, log_level="info"):
    """Write a minimal, RTSP-only MediaMTX configuration."""
    text = """\
# Generated by ThinLite - do not edit, it is rewritten on every start.
logLevel: {log_level}
logDestinations: [stdout]

# Only RTSP is exposed. RTMP/HLS/WebRTC/SRT/API/metrics stay off.
rtsp: yes
rtspAddress: :{rtsp_port}
rtspTransports: [tcp]
rtspEncryption: "no"
rtmp: no
hls: no
webrtc: no
srt: no
api: no
metrics: no
pprof: no

authMethod: internal
authInternalUsers:
  - user: {user}
    pass: {password}
    ips: []
    permissions:
      - action: publish
      - action: read

paths:
  {stream_path}:
    source: publisher
""".format(
        log_level=log_level,
        rtsp_port=int(rtsp_port),
        user=_yaml_str(rtsp_user),
        password=_yaml_str(rtsp_pass),
        stream_path=_yaml_str(stream_path),
    )
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def _yaml_str(value):
    value = str(value)
    return '"%s"' % value.replace("\\", "\\\\").replace('"', '\\"')


def start(binary, config_file, log_file, log=None):
    """Start MediaMTX as a child process; stdout/stderr go to ``log_file``."""
    log = log or (lambda msg: None)
    handle = open(log_file, "ab", buffering=0)
    cmd = [binary, str(config_file)]
    log("starting: %s" % " ".join(cmd))
    creation = 0
    if sys.platform == "win32":
        creation = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    return subprocess.Popen(
        cmd,
        stdout=handle,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        creationflags=creation,
    )


def tail_log(path, lines=12):
    """Return the last ``lines`` of a log file (used in error messages)."""
    try:
        with open(path, "rb") as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(0, size - 8192))
            text = handle.read().decode("utf-8", "replace")
        return "\n".join(text.strip().splitlines()[-lines:])
    except OSError:
        return ""


async def wait_ready(port, host="127.0.0.1", timeout=15.0, process=None):
    """Wait until the RTSP listener accepts TCP connections."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    while loop.time() < deadline:
        if process is not None and process.poll() is not None:
            raise MediamtxError("MediaMTX exited with code %s" % process.returncode)
        try:
            reader, writer = await asyncio.open_connection(host, port)
        except OSError:
            await asyncio.sleep(0.15)
            continue
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        return True
    raise MediamtxError("MediaMTX did not open port %d within %.0fs" % (port, timeout))


def config_path():
    return config_dir() / "mediamtx.yml"
