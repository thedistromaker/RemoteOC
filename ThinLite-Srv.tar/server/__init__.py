"""ThinLite host (server) application.

Runs on the machine being controlled: Linux, macOS or Windows.
"""
