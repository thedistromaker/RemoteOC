"""The control-channel server: authentication, input dispatch, keepalive.

One authenticated client at a time by default.  When a client drops off the
network and reconnects while the server still believes the old session is
alive, the new client takes over (``allow_takeover``) and the stale session
is closed, which is much friendlier for a thin client that roams.

Every held key and mouse button is tracked so that a disconnect always
releases them; otherwise the host ends up with a stuck Ctrl key.
"""

from __future__ import annotations

import asyncio
import hmac
import time

import common.ws as ws
from common import protocol as proto

IDLE_TIMEOUT = 45.0
PING_INTERVAL = 15.0


class ClientSession:
    def __init__(self, connection, peer):
        self.connection = connection
        self.peer = peer
        self.keys = set()
        self.buttons = set()
        self.last_seen = time.monotonic()
        self.closing = False


class ControlServer:
    def __init__(self, *, token, injector, info, host="0.0.0.0", port=8765,
                 allow_takeover=True, logger=None):
        self.token = token
        self.injector = injector
        self.info = dict(info)
        self.host = host
        self.port = int(port)
        self.allow_takeover = allow_takeover
        self.log = logger
        self._server = None
        self._sessions = set()
        self._lock = asyncio.Lock()

    # -- lifecycle ----------------------------------------------------------
    async def start(self):
        self._server = await asyncio.start_server(
            self._handle, self.host, self.port, limit=ws.STREAM_LIMIT, reuse_address=True
        )
        sockets = self._server.sockets or []
        if sockets:
            self.port = sockets[0].getsockname()[1]
        if self.log:
            self.log.info("control channel listening on %s:%d", self.host, self.port)
        return self.port

    async def stop(self):
        if self._server is not None:
            self._server.close()
            try:
                await self._server.wait_closed()
            except Exception:
                pass
            self._server = None
        for session in list(self._sessions):
            try:
                await session.connection.close(ws.CLOSE_GOING_AWAY, "server stopping")
            except Exception:
                pass
        self._sessions.clear()

    @property
    def client_count(self):
        return len(self._sessions)

    # -- connection handling ------------------------------------------------
    async def _handle(self, reader, writer):
        peer_info = writer.get_extra_info("peername")
        peer = "%s:%s" % peer_info[:2] if peer_info else "?"
        try:
            connection, path, _headers = await ws.accept(reader, writer)
        except (ws.WebSocketError, asyncio.TimeoutError) as exc:
            if self.log:
                self.log.warning("handshake from %s rejected: %s", peer, exc)
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            return

        if path.split("?")[0] not in ("/control", "/"):
            await self._reject(connection, "path", "unknown control path %r" % path, ws.CLOSE_UNSUPPORTED)
            return

        session = ClientSession(connection, peer)
        try:
            await self._run_session(session)
        except (ws.WebSocketClosed, ws.WebSocketError) as exc:
            if self.log and not session.closing:
                self.log.info("client %s disconnected: %s", peer, exc)
        except proto.ProtocolError as exc:
            if self.log:
                self.log.warning("protocol error from %s: %s", peer, exc)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # pragma: no cover - defensive
            if self.log:
                self.log.exception("unexpected error serving %s: %s", peer, exc)
        finally:
            self._release_all(session)
            async with self._lock:
                self._sessions.discard(session)
            try:
                await connection.close()
            except Exception:
                pass

    async def _reject(self, connection, code, message, close_code=ws.CLOSE_NORMAL):
        try:
            await connection.send_text(proto.dumps({"t": proto.S_ERROR, "code": code, "msg": message}))
        except Exception:
            pass
        await connection.close(close_code, code)

    async def _run_session(self, session):
        connection = session.connection
        try:
            opcode, payload = await asyncio.wait_for(connection.recv(), proto.HELLO_TIMEOUT)
        except asyncio.TimeoutError:
            await self._reject(connection, "timeout", "no hello frame", ws.CLOSE_GOING_AWAY)
            return
        if opcode != ws.OP_TEXT:
            await self._reject(connection, "protocol", "hello must be a text frame", ws.CLOSE_UNSUPPORTED)
            return

        try:
            hello = proto.loads(payload)
        except proto.ProtocolError as exc:
            await self._reject(connection, "protocol", str(exc), ws.CLOSE_PROTOCOL_ERROR)
            return
        if hello.get("t") != proto.C_HELLO:
            await self._reject(connection, "protocol", "first frame must be hello", ws.CLOSE_PROTOCOL_ERROR)
            return
        if not isinstance(hello.get("token"), str) or not hmac.compare_digest(
                hello["token"], self.token):
            if self.log:
                self.log.warning("bad token from %s", session.peer)
            await self._reject(connection, "auth", "invalid access token", ws.CLOSE_PROTOCOL_ERROR)
            return

        # Register (taking over a stale session if allowed).
        async with self._lock:
            if self._sessions:
                if not self.allow_takeover:
                    busy = True
                else:
                    busy = False
                    for other in list(self._sessions):
                        other.closing = True
                        self._release_all(other)
                        try:
                            await other.connection.close(ws.CLOSE_GOING_AWAY, "taken over")
                        except Exception:
                            pass
                    self._sessions.clear()
            else:
                busy = False
            if not busy:
                self._sessions.add(session)

        if busy:
            await self._reject(connection, "busy", "another client is already connected", ws.CLOSE_TRY_AGAIN)
            return

        width, height = self.injector.screen_size()
        welcome = {
            "t": proto.S_WELCOME,
            "proto": proto.PROTO_VERSION,
            "width": int(width),
            "height": int(height),
            "server": hello.get("name") or session.peer,
        }
        welcome.update(self.info)
        await connection.send_text(proto.dumps(welcome))
        if self.log:
            self.log.info(
                "client %s connected (%s); screen %dx%d, input %s",
                session.peer, hello.get("name") or "?", width, height, self.injector.name,
            )

        await self._message_loop(session)

    async def _message_loop(self, session):
        connection = session.connection
        while True:
            try:
                opcode, payload = await asyncio.wait_for(connection.recv(), IDLE_TIMEOUT)
            except asyncio.TimeoutError:
                if self.log:
                    self.log.info("client %s idle, closing", session.peer)
                await connection.close(ws.CLOSE_GOING_AWAY, "idle timeout")
                return
            if opcode != ws.OP_TEXT:
                continue
            session.last_seen = time.monotonic()
            message = proto.loads(payload)
            if not self._dispatch(session, message):
                return

    def _dispatch(self, session, message):
        kind = message["t"]
        injector = self.injector

        if kind == proto.C_POINTER:
            injector.pointer(proto.clamp_unit(message.get("x")), proto.clamp_unit(message.get("y")))
            return True

        if kind == proto.C_BUTTON:
            button = message.get("b")
            down = bool(message.get("down"))
            if button not in (proto.BTN_LEFT, proto.BTN_MIDDLE, proto.BTN_RIGHT,
                              proto.BTN_SIDE, proto.BTN_EXTRA):
                return True
            if down:
                if button in session.buttons:
                    return True
                session.buttons.add(button)
            else:
                session.buttons.discard(button)
            injector.button(button, down)
            return True

        if kind == proto.C_WHEEL:
            try:
                dy = int(message.get("dy") or 0)
                dx = int(message.get("dx") or 0)
            except (TypeError, ValueError):
                return True
            injector.wheel(max(-20, min(20, dx)), max(-20, min(20, dy)))
            return True

        if kind == proto.C_KEY:
            name = message.get("name")
            down = bool(message.get("down"))
            if not isinstance(name, str):
                return True
            if down:
                if name in session.keys:
                    return True  # host auto-repeat handles held keys
                session.keys.add(name)
            else:
                session.keys.discard(name)
            injector.key(name, down)
            return True

        if kind == proto.C_RELEASE_ALL:
            self._release_all(session)
            return True

        if kind == proto.C_PING:
            self._send_soon(session, {"t": proto.S_PONG, "ts": message.get("ts")})
            return True

        if kind == proto.C_BYE:
            session.closing = True
            return False

        # Unknown message types are ignored on purpose so that older servers
        # keep working with newer clients.
        if self.log:
            self.log.debug("ignoring unknown message type %r", kind)
        return True

    def _send_soon(self, session, message):
        """Fire-and-forget a small JSON message to one client."""
        async def _send():
            try:
                await session.connection.send_text(proto.dumps(message))
            except Exception:
                pass
        try:
            asyncio.get_running_loop().create_task(_send())
        except RuntimeError:  # pragma: no cover - no loop (tests)
            pass

    def _release_all(self, session):
        # Safe to call repeatedly: the sets are cleared as we go.
        for button in list(session.buttons):
            try:
                self.injector.button(button, False)
            except Exception:
                pass
        session.buttons.clear()
        for name in list(session.keys):
            try:
                self.injector.key(name, False)
            except Exception:
                pass
        session.keys.clear()

    def notify(self, message, level="info"):
        """Push a notification to the connected client, if any."""
        for session in list(self._sessions):
            self._send_soon(session, {"t": proto.S_NOTIFY, "level": level, "msg": message})
