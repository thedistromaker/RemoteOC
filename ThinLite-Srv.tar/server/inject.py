"""Input injection backends: turn control messages into real input events.

Three native backends plus one Linux kernel-level fallback:

``x11-xtest``  Linux/X11 via XTEST (no privileges needed)
``uinput``     Linux (X11 *or* Wayland) via /dev/uinput (needs input group)
``win32``      Windows via SetCursorPos + SendInput
``macos``      macOS via Quartz CGEvent (needs Accessibility permission)
``none``       no-op, used by the self-test and ``--inject none``

The client always sends *normalised absolute* pointer coordinates, so the
only place that needs to know the host resolution is
:meth:`Injector.screen_size`.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import os
import struct
import sys

from common.protocol import BTN_EXTRA, BTN_LEFT, BTN_MIDDLE, BTN_RIGHT, BTN_SIDE
from common.protocol import KEY_CODES


class InjectorError(Exception):
    pass


class Injector:
    """Interface implemented by every backend."""

    name = "none"

    def screen_size(self):
        return (0, 0)

    def pointer(self, nx, ny):
        raise NotImplementedError

    def button(self, button, down):
        raise NotImplementedError

    def wheel(self, dx, dy):
        raise NotImplementedError

    def key(self, name, down):
        raise NotImplementedError

    def close(self):
        pass


class NullInjector(Injector):
    """Records calls instead of injecting; used for tests and diagnostics."""

    name = "none"

    def __init__(self, size=(1920, 1080)):
        self.events = []
        self._size = size

    def screen_size(self):
        return self._size

    def pointer(self, nx, ny):
        self.events.append(("pointer", round(nx, 5), round(ny, 5)))

    def button(self, button, down):
        self.events.append(("button", button, bool(down)))

    def wheel(self, dx, dy):
        self.events.append(("wheel", int(dx), int(dy)))

    def key(self, name, down):
        self.events.append(("key", name, bool(down)))


# ---------------------------------------------------------------------------
# Linux / X11 (XTEST)
# ---------------------------------------------------------------------------
#: protocol key name -> X11 keysym.  Numeric keysyms avoid depending on the
#: Xlib string table, and XKeysymToKeycode maps them through the *active*
#: keyboard layout on the host.
X11_KEYSYMS = {
    "esc": 0xFF1B, "backspace": 0xFF08, "tab": 0xFF09, "enter": 0xFF0D, "space": 0x20,
    "ctrl_l": 0xFFE3, "ctrl_r": 0xFFE4, "shift_l": 0xFFE1, "shift_r": 0xFFE2,
    "alt_l": 0xFFE9, "alt_r": 0xFFEA, "meta_l": 0xFFEB, "meta_r": 0xFFEC,
    "capslock": 0xFFE5, "numlock": 0xFF7F, "scrolllock": 0xFF14,
    "minus": 0x2D, "equal": 0x3D, "grave": 0x60, "bracketleft": 0x5B,
    "bracketright": 0x5D, "backslash": 0x5C, "semicolon": 0x3B,
    "apostrophe": 0x27, "comma": 0x2C, "period": 0x2E, "slash": 0x2F,
    "home": 0xFF50, "left": 0xFF51, "up": 0xFF52, "right": 0xFF53,
    "down": 0xFF54, "pageup": 0xFF55, "pagedown": 0xFF56, "end": 0xFF57,
    "insert": 0xFF63, "delete": 0xFFFF, "pause": 0xFF13, "sysrq": 0xFF15,
    "print": 0xFF61, "menu": 0xFF67,
    "kpasterisk": 0xFFAA, "kpplus": 0xFFAB, "kpminus": 0xFFAD, "kpdot": 0xFFAE,
    "kpslash": 0xFFAF, "kpenter": 0xFF8D, "kpequal": 0xFFBD,
    "mute": 0x1008FF12, "volumedown": 0x1008FF11, "volumeup": 0x1008FF13,
    "playpause": 0x1008FF14, "stopcd": 0x1008FF15, "previoussong": 0x1008FF16,
    "nextsong": 0x1008FF17, "browser_back": 0x1008FF26,
    "browser_forward": 0x1008FF27, "browser_refresh": 0x1008FF29,
}
X11_KEYSYMS.update({name: ord(name) for name in "abcdefghijklmnopqrstuvwxyz0123456789"})
X11_KEYSYMS.update({("kp%d" % n): 0xFFB0 + n for n in range(10)})
X11_KEYSYMS.update({("f%d" % n): 0xFFBE + (n - 1) for n in range(1, 13)})

#: protocol button id -> X11 button number (8/9 are the side buttons)
X11_BUTTONS = {BTN_LEFT: 1, BTN_MIDDLE: 2, BTN_RIGHT: 3, BTN_SIDE: 8, BTN_EXTRA: 9}


class X11Injector(Injector):
    name = "x11-xtest"

    def __init__(self, log=None):
        self._log = log or (lambda msg: None)
        libx11 = ctypes.util.find_library("X11") or "libX11.so.6"
        libxtst = ctypes.util.find_library("Xtst") or "libXtst.so.6"
        try:
            self._x = ctypes.CDLL(libx11)
            self._t = ctypes.CDLL(libxtst)
        except OSError as exc:
            raise InjectorError("cannot load libX11/libXtst: %s" % exc) from exc
        self._x.XOpenDisplay.restype = ctypes.c_void_p
        self._x.XOpenDisplay.argtypes = [ctypes.c_char_p]
        self._x.XCloseDisplay.argtypes = [ctypes.c_void_p]
        self._x.XStringToKeysym.restype = ctypes.c_ulong
        self._x.XStringToKeysym.argtypes = [ctypes.c_char_p]
        self._x.XKeysymToKeycode.restype = ctypes.c_ubyte
        self._x.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        self._x.XFlush.argtypes = [ctypes.c_void_p]
        self._x.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self._x.XDefaultScreen.restype = ctypes.c_int
        self._x.XDefaultScreen.argtypes = [ctypes.c_void_p]
        self._x.XDisplayWidth.restype = ctypes.c_int
        self._x.XDisplayWidth.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self._x.XDisplayHeight.restype = ctypes.c_int
        self._x.XDisplayHeight.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self._t.XTestFakeKeyEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
        self._t.XTestFakeButtonEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
        self._t.XTestFakeMotionEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong]
        self._t.XTestQueryExtension.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]

        display = os.environ.get("DISPLAY")
        if not display:
            raise InjectorError("DISPLAY is not set; cannot use XTEST (Wayland: use --inject uinput)")
        self._dpy = self._x.XOpenDisplay(display.encode())
        if not self._dpy:
            raise InjectorError("cannot open X display %r" % display)
        self._screen = self._x.XDefaultScreen(self._dpy)
        a = ctypes.c_int()
        b = ctypes.c_int()
        c = ctypes.c_int()
        d = ctypes.c_int()
        if not self._t.XTestQueryExtension(
                self._dpy, ctypes.byref(a), ctypes.byref(b), ctypes.byref(c), ctypes.byref(d)):
            raise InjectorError("X server has no XTEST extension")
        self._keycodes = {}
        self._size = self.screen_size()
        self._log("X11 injector ready on %s (%dx%d)" % (display, self._size[0], self._size[1]))

    def screen_size(self):
        return (
            self._x.XDisplayWidth(self._dpy, self._screen),
            self._x.XDisplayHeight(self._dpy, self._screen),
        )

    def _flush(self):
        self._x.XFlush(self._dpy)

    def pointer(self, nx, ny):
        width, height = self.screen_size()
        x = int(round(nx * max(0, width - 1)))
        y = int(round(ny * max(0, height - 1)))
        self._t.XTestFakeMotionEvent(self._dpy, self._screen, x, y, 0)
        self._flush()

    def button(self, button, down):
        number = X11_BUTTONS.get(button)
        if number:
            self._t.XTestFakeButtonEvent(self._dpy, number, 1 if down else 0, 0)
            self._flush()

    def wheel(self, dx, dy):
        for number, count in ((4, dy), (5, -dy), (6, dx), (7, -dx)):
            for _ in range(min(abs(int(count)), 20)):
                self._t.XTestFakeButtonEvent(self._dpy, number, 1, 0)
                self._t.XTestFakeButtonEvent(self._dpy, number, 0, 0)
        self._flush()

    def _keycode(self, name):
        if name in self._keycodes:
            return self._keycodes[name]
        keysym = X11_KEYSYMS.get(name)
        code = 0
        if keysym:
            code = self._x.XKeysymToKeycode(self._dpy, keysym)
        self._keycodes[name] = code
        return code

    def key(self, name, down):
        code = self._keycode(name)
        if code:
            self._t.XTestFakeKeyEvent(self._dpy, code, 1 if down else 0, 0)
            self._flush()

    def close(self):
        if getattr(self, "_dpy", None):
            try:
                self._x.XCloseDisplay(self._dpy)
            except Exception:
                pass
            self._dpy = None


# ---------------------------------------------------------------------------
# Linux / uinput (works on Wayland and X11, needs /dev/uinput access)
# ---------------------------------------------------------------------------
_EV_SYN, _EV_KEY, _EV_REL, _EV_ABS = 0x00, 0x01, 0x02, 0x03
_SYN_REPORT = 0
_ABS_X, _ABS_Y = 0x00, 0x01
_REL_HWHEEL, _REL_WHEEL = 0x06, 0x08
_BTN_LEFT, _BTN_RIGHT, _BTN_MIDDLE, _BTN_SIDE, _BTN_EXTRA = 0x110, 0x111, 0x112, 0x113, 0x114

_UI_DEV_CREATE = 0x5501
_UI_DEV_DESTROY = 0x5502


def _ioc(direction, kind, number, size):
    return (direction << 30) | (size << 16) | (ord(kind) << 8) | number


_UI_SET_EVBIT = _ioc(1, "U", 100, 4)
_UI_SET_KEYBIT = _ioc(1, "U", 101, 4)
_UI_SET_RELBIT = _ioc(1, "U", 102, 4)
_UI_SET_ABSBIT = _ioc(1, "U", 103, 4)


class _UinputUserDev(ctypes.Structure):
    _fields_ = [
        ("name", ctypes.c_char * 80),
        ("input_id", ctypes.c_uint16 * 4),
        ("ff_effects_max", ctypes.c_uint32),
        ("absmax", ctypes.c_int32 * 64),
        ("absmin", ctypes.c_int32 * 64),
        ("absfuzz", ctypes.c_int32 * 64),
        ("absflat", ctypes.c_int32 * 64),
    ]


class UinputInjector(Injector):
    """Absolute-pointer + keyboard injection through the kernel uinput API.

    This is the portable Linux backend: it works on X11 and on Wayland
    compositors, because the compositor sees ordinary input devices.  It needs
    write access to /dev/uinput (``input`` group) plus, on some systems, a
    udev rule.
    """

    name = "uinput"
    ABS_MAX = 32767

    def __init__(self, device="/dev/uinput", log=None):
        import fcntl

        self._fcntl = fcntl
        self._log = log or (lambda msg: None)
        self._device = device
        try:
            self._pointer_fd = self._create_pointer()
            self._keyboard_fd = self._create_keyboard()
        except OSError as exc:
            self.close()
            raise InjectorError(
                "cannot create uinput devices (%s): is %s writable by this user? "
                "Add yourself to the 'input' group, e.g. "
                "'sudo usermod -aG input $USER' then log out and back in." % (exc, device)
            ) from exc
        self._size = self._detect_size()
        self._log("uinput injector ready (%dx%d)" % self._size)

    # -- device plumbing ----------------------------------------------------
    def _open(self):
        flags = os.O_WRONLY | os.O_NONBLOCK
        return os.open(self._device, flags)

    def _bits(self, fd, request, values):
        for value in values:
            self._fcntl.ioctl(fd, request, struct.pack("i", value))

    def _create_pointer(self):
        fd = self._open()
        self._bits(fd, _UI_SET_EVBIT, [_EV_KEY, _EV_ABS, _EV_REL])
        self._bits(fd, _UI_SET_KEYBIT, [_BTN_LEFT, _BTN_RIGHT, _BTN_MIDDLE, _BTN_SIDE, _BTN_EXTRA])
        self._bits(fd, _UI_SET_ABSBIT, [_ABS_X, _ABS_Y])
        self._bits(fd, _UI_SET_RELBIT, [_REL_WHEEL, _REL_HWHEEL])
        # VirtualBus (0x06) keeps it away from real hardware permissions/quirks.
        self._register(fd, "ThinLite Pointer")
        return fd

    def _create_keyboard(self):
        fd = self._open()
        self._bits(fd, _UI_SET_EVBIT, [_EV_KEY])
        self._bits(fd, _UI_SET_KEYBIT, sorted(set(KEY_CODES.values())))
        self._register(fd, "ThinLite Keyboard")
        return fd

    def _register(self, fd, name):
        dev = _UinputUserDev()
        dev.name = name.encode()[:79]
        dev.input_id[0] = 0x06  # BUS_VIRTUAL
        dev.input_id[1] = 0x1D6B  # vendor: Linux Foundation
        dev.input_id[2] = 0x0001
        dev.ff_effects_max = 0
        for axis in (_ABS_X, _ABS_Y):
            dev.absmax[axis] = self.ABS_MAX
            dev.absmin[axis] = 0
            dev.absfuzz[axis] = 0
            dev.absflat[axis] = 0
        os.write(fd, bytes(dev))
        self._fcntl.ioctl(fd, _UI_DEV_CREATE, 0)

    def _emit(self, fd, kind, code, value):
        os.write(fd, struct.pack("llHHi", 0, 0, kind, code, value))
        os.write(fd, struct.pack("llHHi", 0, 0, _EV_SYN, _SYN_REPORT, 0))

    def _detect_size(self):
        """Best effort: use the primary DRM mode, else assume 1920x1080."""
        try:
            import glob

            for status in glob.glob("/sys/class/drm/*/status"):
                try:
                    if open(status).read().strip() != "connected":
                        continue
                except OSError:
                    continue
                modes = os.path.join(os.path.dirname(status), "modes")
                try:
                    first = open(modes).readline().strip()
                except OSError:
                    continue
                if "x" in first:
                    width, _, height = first.partition("x")
                    return int(width), int(height)
        except Exception:
            pass
        return 1920, 1080

    # -- Injector interface -------------------------------------------------
    def screen_size(self):
        return self._size

    def pointer(self, nx, ny):
        x = int(round(nx * self.ABS_MAX))
        y = int(round(ny * self.ABS_MAX))
        self._emit(self._pointer_fd, _EV_ABS, _ABS_X, x)
        self._emit(self._pointer_fd, _EV_ABS, _ABS_Y, y)

    def button(self, button, down):
        code = {
            BTN_LEFT: _BTN_LEFT, BTN_MIDDLE: _BTN_MIDDLE, BTN_RIGHT: _BTN_RIGHT,
            BTN_SIDE: _BTN_SIDE, BTN_EXTRA: _BTN_EXTRA,
        }.get(button)
        if code:
            self._emit(self._pointer_fd, _EV_KEY, code, 1 if down else 0)

    def wheel(self, dx, dy):
        if dy:
            self._emit(self._pointer_fd, _EV_REL, _REL_WHEEL, int(dy))
        if dx:
            self._emit(self._pointer_fd, _EV_REL, _REL_HWHEEL, int(dx))

    def key(self, name, down):
        code = KEY_CODES.get(name)
        if code:
            self._emit(self._keyboard_fd, _EV_KEY, code, 1 if down else 0)

    def close(self):
        for attr in ("_pointer_fd", "_keyboard_fd"):
            fd = getattr(self, attr, None)
            if fd is None:
                continue
            try:
                self._fcntl.ioctl(fd, _UI_DEV_DESTROY, 0)
            except Exception:
                pass
            try:
                os.close(fd)
            except OSError:
                pass
            setattr(self, attr, None)


# ---------------------------------------------------------------------------
# Windows
# ---------------------------------------------------------------------------
VK = {
    "esc": 0x1B, "backspace": 0x08, "tab": 0x09, "enter": 0x0D, "space": 0x20,
    "ctrl_l": 0xA2, "ctrl_r": 0xA3, "shift_l": 0xA0, "shift_r": 0xA1,
    "alt_l": 0xA4, "alt_r": 0xA5, "meta_l": 0x5B, "meta_r": 0x5C,
    "capslock": 0x14, "numlock": 0x90, "scrolllock": 0x91,
    "grave": 0xC0, "minus": 0xBD, "equal": 0xBB, "bracketleft": 0xDB,
    "bracketright": 0xDD, "backslash": 0xDC, "semicolon": 0xBA,
    "apostrophe": 0xDE, "comma": 0xBC, "period": 0xBE, "slash": 0xBF,
    "home": 0x24, "left": 0x25, "up": 0x26, "right": 0x27, "end": 0x23,
    "down": 0x28, "pageup": 0x21, "pagedown": 0x22, "insert": 0x2D,
    "delete": 0x2E, "pause": 0x13, "print": 0x2C, "menu": 0x5D,
    "kpasterisk": 0x6A, "kpplus": 0x6B, "kpminus": 0x6D, "kpdot": 0x6E,
    "kpslash": 0x6F, "kpenter": 0x0D, "kpequal": 0x92,
    "mute": 0xAD, "volumedown": 0xAE, "volumeup": 0xAF,
    "playpause": 0xB3, "stopcd": 0xB2, "previoussong": 0xB1, "nextsong": 0xB0,
    "browser_back": 0xA6, "browser_forward": 0xA7, "browser_refresh": 0xA8,
    "102nd": 0xE2,
}
VK.update({name: ord(name.upper()) for name in "abcdefghijklmnopqrstuvwxyz"})
VK.update({"0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34,
           "5": 0x35, "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39})
VK.update({("kp%d" % n): 0x60 + n for n in range(10)})
VK.update({("f%d" % n): 0x6F + n for n in range(1, 13)})

_MOUSEEVENTF = {
    "left": (0x0002, 0x0004),
    "right": (0x0008, 0x0010),
    "middle": (0x0020, 0x0040),
    "x1": (0x0080, 0x0100),
    "x2": (0x0080, 0x0100),
}


class Win32Injector(Injector):
    name = "win32"

    def __init__(self, log=None):
        if sys.platform != "win32":
            raise InjectorError("win32 injector used on %s" % sys.platform)
        self._log = log or (lambda msg: None)
        self._u = ctypes.windll.user32
        try:
            self._u.SetProcessDPIAware()
        except Exception:
            pass
        self._u.mouse_event.argtypes = [
            ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_size_t]
        self._size = self.screen_size()
        self._log("win32 injector ready (%dx%d)" % self._size)

    def screen_size(self):
        # Virtual screen so that multi-monitor desktops map 1:1 with gdigrab.
        return (self._u.GetSystemMetrics(78), self._u.GetSystemMetrics(79))

    def _origin(self):
        return self._u.GetSystemMetrics(76), self._u.GetSystemMetrics(77)

    def pointer(self, nx, ny):
        width, height = self.screen_size()
        ox, oy = self._origin()
        x = ox + int(round(nx * max(0, width - 1)))
        y = oy + int(round(ny * max(0, height - 1)))
        self._u.SetCursorPos(x, y)

    def button(self, button, down):
        name = {BTN_LEFT: "left", BTN_MIDDLE: "middle", BTN_RIGHT: "right",
                BTN_SIDE: "x1", BTN_EXTRA: "x2"}.get(button)
        if not name:
            return
        flags = _MOUSEEVENTF[name]
        mask = flags[0] if down else flags[1]
        data = {BTN_SIDE: 1, BTN_EXTRA: 2}.get(button, 0)
        self._u.mouse_event(mask, 0, 0, data, 0)

    def wheel(self, dx, dy):
        if dy:
            self._u.mouse_event(0x0800, 0, 0, int(dy) * 120, 0)
        if dx:
            self._u.mouse_event(0x1000, 0, 0, int(dx) * 120, 0)

    def key(self, name, down):
        vk = VK.get(name)
        if not vk:
            return
        self._u.keybd_event(vk, 0, 0 if down else 0x0002, 0)


# ---------------------------------------------------------------------------
# macOS
# ---------------------------------------------------------------------------
#: protocol key name -> ANSI virtual key code
MAC_VK = {
    "a": 0, "s": 1, "d": 2, "f": 3, "h": 4, "g": 5, "z": 6, "x": 7, "c": 8, "v": 9,
    "b": 11, "q": 12, "w": 13, "e": 14, "r": 15, "y": 16, "t": 17,
    "1": 18, "2": 19, "3": 20, "4": 21, "6": 22, "5": 23, "equal": 24, "9": 25,
    "7": 26, "minus": 27, "8": 28, "0": 29, "bracketright": 30, "o": 31, "u": 32,
    "bracketleft": 33, "i": 34, "p": 35, "enter": 36, "l": 37, "j": 38,
    "apostrophe": 39, "k": 40, "semicolon": 41, "backslash": 42, "comma": 43,
    "slash": 44, "n": 45, "m": 46, "period": 47, "tab": 48, "space": 49,
    "grave": 50, "backspace": 51, "esc": 53, "meta_r": 54, "meta_l": 55,
    "shift_l": 56, "capslock": 57, "alt_l": 58, "ctrl_l": 59, "shift_r": 60,
    "alt_r": 61, "ctrl_r": 62, "kpdot": 65, "kpasterisk": 67, "kpplus": 69,
    "numlock": 71, "kpslash": 75, "kpenter": 76, "kpminus": 78, "kpequal": 81,
    "kp0": 82, "kp1": 83, "kp2": 84, "kp3": 85, "kp4": 86, "kp5": 87,
    "kp6": 88, "kp7": 89, "kp8": 91, "kp9": 92,
    "f1": 122, "f2": 120, "f3": 99, "f4": 118, "f5": 96, "f6": 97,
    "f7": 98, "f8": 100, "f9": 101, "f10": 109, "f11": 103, "f12": 111,
    "home": 115, "end": 119, "pageup": 116, "pagedown": 121,
    "left": 123, "right": 124, "down": 125, "up": 126, "delete": 117, "insert": 114,
    "mute": 74, "volumedown": 73, "volumeup": 72,
}

#: macOS decides shifted characters from event *flags*, not from key state,
#: so the injector has to track and attach them on every key event.
_CG_FLAGS = {
    "shift": 0x00020000, "ctrl": 0x00040000, "alt": 0x00080000,
    "cmd": 0x00100000, "caps": 0x00010000,
}


class _CGPoint(ctypes.Structure):
    _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]


class _CGSize(ctypes.Structure):
    _fields_ = [("width", ctypes.c_double), ("height", ctypes.c_double)]


class _CGRect(ctypes.Structure):
    _fields_ = [("origin", _CGPoint), ("size", _CGSize)]


class MacOSInjector(Injector):
    name = "macos"

    _TYPES = {
        BTN_LEFT: (1, 2, 6),      # down, up, drag
        BTN_RIGHT: (3, 4, 7),
        BTN_MIDDLE: (25, 26, 27),
        BTN_SIDE: (25, 26, 27),
        BTN_EXTRA: (25, 26, 27),
    }

    def __init__(self, log=None):
        if sys.platform != "darwin":
            raise InjectorError("macos injector used on %s" % sys.platform)
        self._log = log or (lambda msg: None)
        framework = "/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics"
        cf = "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation"
        try:
            self._cg = ctypes.CDLL(framework)
            self._cf = ctypes.CDLL(cf)
        except OSError as exc:
            raise InjectorError("cannot load CoreGraphics: %s" % exc) from exc

        self._cg.CGMainDisplayID.restype = ctypes.c_uint32
        self._cg.CGDisplayBounds.restype = _CGRect
        self._cg.CGDisplayBounds.argtypes = [ctypes.c_uint32]
        self._cg.CGEventCreateMouseEvent.restype = ctypes.c_void_p
        self._cg.CGEventCreateMouseEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_uint32, _CGPoint, ctypes.c_uint32]
        self._cg.CGEventCreateKeyboardEvent.restype = ctypes.c_void_p
        self._cg.CGEventCreateKeyboardEvent.argtypes = [
            ctypes.c_void_p, ctypes.c_uint16, ctypes.c_bool]
        self._cg.CGEventSetFlags.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
        self._cg.CGEventPost.argtypes = [ctypes.c_uint32, ctypes.c_void_p]
        self._cg.CGWarpMouseCursorPosition.argtypes = [_CGPoint]
        self._cg.CGEventCreateScrollWheelEvent.restype = ctypes.c_void_p
        self._cf.CFRelease.argtypes = [ctypes.c_void_p]
        self._cg.CGPreflightPostEventAccess.restype = ctypes.c_bool

        if not self._cg.CGPreflightPostEventAccess():
            self._log(
                "warning: this process is not trusted for Accessibility input injection; "
                "enable it in System Settings > Privacy & Security > Accessibility"
            )
        self._mods = {"shift": False, "ctrl": False, "alt": False, "cmd": False, "caps": False}
        self._pos = (0.0, 0.0)
        ctypes.CGPoint = _CGPoint
        self._size = self.screen_size()
        self._log("macOS injector ready (%dx%d)" % self._size)

    def screen_size(self):
        bounds = self._cg.CGDisplayBounds(self._cg.CGMainDisplayID())
        return (int(bounds.size.width), int(bounds.size.height))

    def _flags(self):
        flags = 0
        for name, enabled in self._mods.items():
            if enabled:
                flags |= _CG_FLAGS[name]
        return flags

    def _release(self, ref):
        if ref:
            self._cf.CFRelease(ref)

    def _post_mouse(self, event_type, x, y, button=0):
        event = self._cg.CGEventCreateMouseEvent(None, event_type, _CGPoint(x, y), button)
        if event:
            self._cg.CGEventSetFlags(event, self._flags())
            self._cg.CGEventPost(0, event)  # kCGHIDEventTap
            self._release(event)

    def pointer(self, nx, ny):
        width, height = self.screen_size()
        self._pos = (nx * max(0, width - 1), ny * max(0, height - 1))
        self._cg.CGWarpMouseCursorPosition(_CGPoint(*self._pos))

    def button(self, button, down):
        types = self._TYPES.get(button)
        if not types:
            return
        # A mouse event carries its own location: pass the position the
        # pointer was warped to, or the click lands wherever (0,0) is.
        self._post_mouse(
            types[0] if down else types[1], self._pos[0], self._pos[1],
            0 if button in (BTN_LEFT, BTN_RIGHT) else 2,
        )

    def wheel(self, dx, dy):
        event = self._cg.CGEventCreateScrollWheelEvent(None, 1, 2, int(dy), int(dx))
        if event:
            self._cg.CGEventPost(0, event)
            self._release(event)

    def key(self, name, down):
        code = MAC_VK.get(name)
        if code is None:
            return
        if name == "shift_l" or name == "shift_r":
            self._mods["shift"] = down
        elif name == "ctrl_l" or name == "ctrl_r":
            self._mods["ctrl"] = down
        elif name == "alt_l" or name == "alt_r":
            self._mods["alt"] = down
        elif name == "meta_l" or name == "meta_r":
            self._mods["cmd"] = down
        elif name == "capslock" and down:
            self._mods["caps"] = not self._mods["caps"]
        event = self._cg.CGEventCreateKeyboardEvent(None, code, bool(down))
        if event:
            self._cg.CGEventSetFlags(event, self._flags())
            self._cg.CGEventPost(0, event)
            self._release(event)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------
def create_injector(mode="auto", log=None):
    """Instantiate the best injector for this machine."""
    log = log or (lambda msg: None)
    mode = (mode or "auto").lower()

    if mode == "none":
        return NullInjector()
    if mode == "xtest":
        return X11Injector(log)
    if mode == "uinput":
        return UinputInjector(log=log)
    if mode == "win32":
        return Win32Injector(log)
    if mode == "macos":
        return MacOSInjector(log)
    if mode != "auto":
        raise InjectorError("unknown injector %r (auto, xtest, uinput, win32, macos, none)" % mode)

    if sys.platform == "darwin":
        return MacOSInjector(log)
    if sys.platform == "win32":
        return Win32Injector(log)
    # Linux: prefer XTEST on X11 (no extra privileges).  On Wayland, or when
    # XTEST is unavailable, fall back to uinput.
    session = os.environ.get("XDG_SESSION_TYPE", "").lower()
    if session != "wayland" and os.environ.get("DISPLAY"):
        try:
            return X11Injector(log)
        except InjectorError as exc:
            log("XTEST unavailable: %s" % exc)
    try:
        return UinputInjector(log=log)
    except InjectorError as exc:
        if os.environ.get("DISPLAY"):
            return X11Injector(log)
        raise InjectorError(
            "no usable injection backend: %s. On Wayland grant /dev/uinput access "
            "or run an Xorg session." % exc
        ) from exc
