"""ffmpeg screen-capture + H.264 encoder command construction.

Design notes
------------
* Target: **1280x720 @ 60 fps, 5 Mbps, 8-bit 4:2:0, SDR/BT.709**.  720p60
  is a deliberately better fit than 1080p30 for a thin client: it is
  *fewer* pixels per second than 1080p30 (55.3 vs 62.2 Mpx/s), so a Pi Zero
  2 W VideoCore VI decodes it comfortably, while halving the motion-to-photon
  latency because a frame is ready every 16.7 ms instead of every 33 ms.
* Latency: no B-frames, one second GOP, slice-max-size near the MTU, CBR.
* HDR/10-bit sources are forced down to 8-bit yuv420p with explicit BT.709
  tagging, so nothing downstream has to negotiate colour.
"""

from __future__ import annotations

import os
import subprocess
import sys

#: Encoders we know how to configure, in decreasing order of preference per
#: platform.  ``libx264`` is always available and is the fallback.
ENCODER_PREFERENCE = {
    "darwin": ("videotoolbox", "libx264"),
    "win32": ("nvenc", "qsv", "libx264"),
    "linux": ("nvenc", "qsv", "v4l2m2m", "libx264"),
}

FFMPEG_ENCODER_NAMES = {
    "libx264": "libx264",
    "videotoolbox": "h264_videotoolbox",
    "nvenc": "h264_nvenc",
    "qsv": "h264_qsv",
    "v4l2m2m": "h264_v4l2m2m",
}


class CaptureError(Exception):
    pass


_VERIFIED_ENCODERS = {}


def encoder_works(key, ffmpeg="ffmpeg"):
    """Check that an encoder can really run on this machine.

    ``ffmpeg -encoders`` only reports what the build was compiled with, so
    ``auto`` must not trust it: a build with NVENC but no NVIDIA GPU (or QSV
    without a Gen device) will fail on the first frame.  Encode one tiny frame
    and see.  Results are cached per process.
    """
    if key == "libx264":
        return True
    if key in _VERIFIED_ENCODERS:
        return _VERIFIED_ENCODERS[key]
    name = FFMPEG_ENCODER_NAMES.get(key)
    if not name:
        return False
    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
        "-f", "lavfi", "-i", "color=c=black:size=128x128:rate=1:duration=1",
        "-frames:v", "1", "-c:v", name, "-f", "null", "-",
    ]
    try:
        result = subprocess.run(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=20, check=False,
        )
        ok = result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        ok = False
    _VERIFIED_ENCODERS[key] = ok
    return ok


def probe_encoders(ffmpeg="ffmpeg"):
    """Return the set of H.264 encoder short names this ffmpeg build has."""
    try:
        out = subprocess.run(
            [ffmpeg, "-hide_banner", "-encoders"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=20,
            check=False,
        ).stdout.decode("utf-8", "replace")
    except (OSError, subprocess.SubprocessError):
        return set()
    found = set()
    for line in out.splitlines():
        parts = line.split()
        # Format: " V..... h264_nvenc  NVIDIA NVENC H.264 encoder"
        if len(parts) >= 2 and parts[1].startswith("h264_"):
            found.add(parts[1][5:])
    return found


def resolve_encoder(requested="auto", ffmpeg="ffmpeg"):
    """Pick a concrete encoder key from :data:`ENCODER_PREFERENCE`."""
    available = probe_encoders(ffmpeg)
    if requested and requested != "auto":
        key = requested.lower()
        if key not in FFMPEG_ENCODER_NAMES:
            raise CaptureError("unknown encoder %r (choose auto, %s)" % (
                requested, ", ".join(sorted(FFMPEG_ENCODER_NAMES))))
        if key != "libx264" and key not in available:
            raise CaptureError("ffmpeg build has no %s encoder" % key)
        if not encoder_works(key, ffmpeg):
            raise CaptureError(
                "encoder %s is compiled in but does not work on this machine" % key)
        return key
    for key in ENCODER_PREFERENCE.get(sys.platform, ("libx264",)):
        if key == "libx264":
            return "libx264"
        if key in available and encoder_works(key, ffmpeg):
            return key
    return "libx264"


def encoder_args(key, bitrate_kbps, fps, width, height):
    bitrate = "%dk" % int(bitrate_kbps)
    buf = "%dk" % int(bitrate_kbps)
    gop = str(max(1, int(fps)))  # one second between keyframes
    common_profile = ["-profile:v", "main", "-pix_fmt", "yuv420p", "-an"]

    if key == "libx264":
        # ultrafast/zerolatency implies no CABAC and no 8x8 transform, so x264
        # would silently downgrade "main" to baseline anyway: declare baseline
        # and be honest about what goes on the wire.  It also means any decoder,
        # including the Pi's stateless V4L2 M2M block, accepts it without a
        # fallback path.
        #
        # slices=4 (and *no* slice-max-size) is deliberate: slice-max-size
        # shreds a 720p keyframe into 50+ slices, and MediaMTX drops any frame
        # above 50 NALUs ("NALU count exceeds maximum allowed") - which silently
        # throws away every keyframe.  Four slices still give the decoder
        # intra-frame parallelism while keeping a frame at ~7 NALUs.
        return [
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-tune", "zerolatency",
            "-profile:v", "baseline",
            "-level:v", "4.0",
            "-pix_fmt", "yuv420p",
            "-b:v", bitrate,
            "-maxrate", bitrate,
            "-bufsize", buf,
            "-g", gop,
            "-keyint_min", gop,
            "-sc_threshold", "0",
            "-bf", "0",
            "-refs", "1",
            "-x264-params",
            "nal-hrd=cbr:filler=1:repeat-headers=1:rc-lookahead=0:sync-lookahead=0:slices=4",
            "-an",
        ]
    if key == "videotoolbox":
        return [
            "-c:v", "h264_videotoolbox",
            "-realtime", "1",
            "-allow_sw", "1",
            "-b:v", bitrate,
            "-maxrate", bitrate,
            "-bufsize", buf,
            "-g", gop,
            "-bf", "0",
        ] + common_profile
    if key == "nvenc":
        return [
            "-c:v", "h264_nvenc",
            "-preset", "p1",
            "-tune", "ull",
            "-rc", "cbr",
            "-zerolatency", "1",
            "-b:v", bitrate,
            "-maxrate", bitrate,
            "-bufsize", buf,
            "-g", gop,
            "-bf", "0",
            "-delay", "0",
        ] + common_profile
    if key == "qsv":
        return [
            "-c:v", "h264_qsv",
            "-preset", "veryfast",
            "-low_delay_brc", "1",
            "-b:v", bitrate,
            "-maxrate", bitrate,
            "-bufsize", buf,
            "-g", gop,
            "-bf", "0",
        ] + common_profile
    if key == "v4l2m2m":
        # Hardware encoder path for a Raspberry Pi acting as the host.
        return [
            "-c:v", "h264_v4l2m2m",
            "-num_output_buffers", "8",
            "-num_capture_buffers", "4",
            "-b:v", bitrate,
            "-g", gop,
            "-bf", "0",
        ] + common_profile
    raise CaptureError("unhandled encoder %r" % key)


def _pixel_scale(width, height, fps):
    """Scale + pad to exactly ``width``x``height`` without distorting, then
    convert any 10-bit/HDR input to 8-bit 4:2:0."""
    return (
        "scale=%d:%d:force_original_aspect_ratio=decrease:force_divisible_by=2,"
        "pad=%d:%d:(ow-iw)/2:(oh-ih)/2:color=black,"
        "setsar=1,fps=%d,format=yuv420p"
    ) % (width, height, width, height, fps)


def _parse_region(region):
    """Parse ``WxH+X+Y`` into ``(width, height, x, y)``."""
    if not region:
        return None
    try:
        size, _, offset = region.partition("+")
        w, _, h = size.partition("x")
        x, _, y = offset.partition("+")
        return int(w), int(h), int(x or 0), int(y or 0)
    except ValueError as exc:
        raise CaptureError("bad --capture-region %r (want WxH+X+Y)" % region) from exc


def detect_capture(source="auto"):
    """Choose a capture backend for the current platform."""
    if source and source != "auto":
        return source
    if sys.platform == "darwin":
        return "avfoundation"
    if sys.platform == "win32":
        return "gdigrab"
    if sys.platform.startswith("linux"):
        session = os.environ.get("XDG_SESSION_TYPE", "").lower()
        if session == "wayland":
            return "pipewire"
        return "x11grab"
    raise CaptureError("unsupported platform %s" % sys.platform)


def avfoundation_screen_index(ffmpeg="ffmpeg"):
    """Find the avfoundation index of the primary screen capture device.

    Device indices are not stable across macOS versions, so ask ffmpeg.
    """
    try:
        proc = subprocess.run(
            [ffmpeg, "-hide_banner", "-f", "avfoundation", "-list_devices", "true", "-i", ""],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return "1"
    current = None
    for line in proc.stdout.decode("utf-8", "replace").splitlines():
        stripped = line.strip()
        if "AVFoundation video devices" in stripped:
            current = "video"
            continue
        if "AVFoundation audio devices" in stripped:
            current = "audio"
            continue
        if current != "video" or "[" not in stripped:
            continue
        # "[AVFoundation indev @ 0x7f...] [1] Capture screen 0"
        if "Capture screen" in stripped:
            tail = stripped.rsplit("[", 1)[-1]
            index = tail.split("]", 1)[0]
            if index.isdigit():
                return index
    return "1"


def input_args(capture, cfg, probe_log=None):
    """Build the ffmpeg *input* section for the selected capture backend."""
    region = _parse_region(cfg.capture_region)
    fps = int(cfg.fps)

    if capture == "x11grab":
        display = cfg.display or os.environ.get("DISPLAY") or ":0.0"
        args = ["-f", "x11grab", "-framerate", str(fps), "-draw_mouse", "1"]
        if region:
            w, h, x, y = region
            args += ["-video_size", "%dx%d" % (w, h)]
            target = "%s+%d,%d" % (display, x, y)
        else:
            target = display
        return args + ["-i", target]

    if capture == "gdigrab":
        args = ["-f", "gdigrab", "-framerate", str(fps), "-draw_mouse", "1"]
        if region:
            w, h, x, y = region
            args += ["-offset_x", str(x), "-offset_y", str(y), "-video_size", "%dx%d" % (w, h)]
        return args + ["-i", "desktop"]

    if capture == "ddagrab":
        # DXGI Desktop Duplication: much cheaper than gdigrab on Windows 8+.
        # hwdownload is required because libx264 is a software encoder.
        graph = "ddagrab=framerate=%d,hwdownload,format=bgra" % fps
        return ["-f", "lavfi", "-i", graph]

    if capture == "avfoundation":
        index = os.environ.get("THINCAST_SCREEN_INDEX") or avfoundation_screen_index(cfg.ffmpeg)
        args = [
            "-f", "avfoundation",
            "-capture_cursor", "1",
            "-capture_mouse_clicks", "1",
            "-framerate", str(fps),
            "-pix_fmt", "uyvy422",
        ]
        if region:
            w, h, x, y = region
            args += ["-video_size", "%dx%d" % (w, h)]
        return args + ["-i", "%s:none" % index]

    if capture == "pipewire":
        # Wayland: ffmpeg's pipewire grabber needs a node id; the screen-cast
        # portal hands one out interactively, so pass it via THINCAST_PIPEWIRE_NODE.
        node = os.environ.get("THINCAST_PIPEWIRE_NODE", "0")
        return ["-f", "pipewire", "-framerate", str(fps), "-i", node]

    raise CaptureError(
        "unknown capture backend %r (x11grab, gdigrab, ddagrab, avfoundation, pipewire)" % capture
    )


def build_command(cfg, publish_url=None, encoder=None):
    """Return the full ffmpeg argv that captures the screen and publishes RTSP."""
    capture = detect_capture(cfg.capture)
    enc = encoder
    if not enc or enc == "auto":
        enc = resolve_encoder(cfg.encoder, cfg.ffmpeg)
    url = publish_url or cfg.publish_url
    if not url:
        raise CaptureError("no RTSP publish URL configured")

    cmd = [cfg.ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "warning"]
    cmd += list(cfg.input_args)
    cmd += input_args(capture, cfg)
    cmd += ["-vf", _pixel_scale(int(cfg.width), int(cfg.height), int(cfg.fps))]
    cmd += encoder_args(enc, int(cfg.bitrate_kbps), int(cfg.fps), int(cfg.width), int(cfg.height))
    # Explicit SDR tagging: no HDR, no 10-bit, no surprise colour shifts.
    cmd += [
        "-colorspace", "bt709",
        "-color_primaries", "bt709",
        "-color_trc", "bt709",
        "-color_range", "tv",
    ]
    cmd += ["-f", "rtsp", "-rtsp_transport", "tcp", "-muxdelay", "0.05", url]
    return cmd, capture, enc


def describe(cfg):
    capture = detect_capture(cfg.capture)
    try:
        enc = resolve_encoder(cfg.encoder, cfg.ffmpeg)
    except CaptureError:
        enc = "libx264"
    return "%s -> h264 (%s) %dx%d@%d %dkbps" % (
        capture, enc, int(cfg.width), int(cfg.height), int(cfg.fps), int(cfg.bitrate_kbps)
    )
